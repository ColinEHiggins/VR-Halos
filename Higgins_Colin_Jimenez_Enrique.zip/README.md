# VR-Halos
Final Project for Computer Graphics by Colin Higgins and Enrique Jimenez
